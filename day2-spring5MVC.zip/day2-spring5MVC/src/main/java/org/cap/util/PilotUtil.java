package org.cap.util;

import java.util.ArrayList;
import java.util.List;

public class PilotUtil {
	
	public static List<String> getQualifications(){
		List<String> cities=new ArrayList<>();
		cities.add("MBA");
		cities.add("MA");
		cities.add("BE");
		cities.add("BCOM");
		cities.add("ME");
		cities.add("MCA");
		return cities;
		
	}
	
	public static List<String> getAllCities(){
		List<String> cities=new ArrayList<>();
		cities.add("Chennai");
		cities.add("Pune");
		cities.add("Hyderabad");cities.add("Bangalore");
		cities.add("Mubai");
		cities.add("Gurgaon");
		return cities;
		
	}
}
