package org.cap.controller;

import javax.validation.Valid;

import org.cap.model.Pilot;
import org.cap.service.IPilotService;
import org.cap.util.PilotUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PilotController {
	
	private IPilotService pilotservice;

	
	@RequestMapping(value="/savePilot",method=RequestMethod.POST)
	public String savePilotDetails(
			@Valid @ModelAttribute("pilot") Pilot pilot,
			BindingResult result) {
		if(result.hasErrors())
			return "pilotPage";
		else
		//System.out.println(pilot);
			return "redirect:/pilotPage";
	}
	
	@RequestMapping("/pilotPage")
	public String pilotPage(ModelMap map) {
		map.addAttribute("pilot", new Pilot());
		map.addAttribute("cities", PilotUtil.getAllCities());
		return "pilotPage";
	}
}
