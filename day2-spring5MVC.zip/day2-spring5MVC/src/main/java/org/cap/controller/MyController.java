package org.cap.controller;

import java.util.List;

import org.cap.model.Pilot;
import org.cap.util.PilotUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	

	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		String msg="Welcome! Hello World from Spring5 MVC!";
		
		return new ModelAndView("success", "greet", msg);
	}
	
	
	
	
	@RequestMapping(value="/validateLogin",method=RequestMethod.POST)
	public String  validateLogin(
			@RequestParam("userName")String userName,
			@RequestParam("userPwd") String userPwd,
			ModelMap map) {
		
		if(userName.equals("tom") && userPwd.equals("tom123")) {
			map.addAttribute("pilot", new Pilot());
			map.addAttribute("cities", PilotUtil.getAllCities());
			return "pilotPage";
		}
		else
			return "redirect:/";
	}
	
	
	
	
	
}
