package org.cap.service;

import org.cap.model.Pilot;

public interface IPilotService {
	
	public void savePilot(Pilot pilot);

}
