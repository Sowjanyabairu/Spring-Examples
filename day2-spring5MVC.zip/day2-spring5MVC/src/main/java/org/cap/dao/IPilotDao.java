package org.cap.dao;

import org.cap.model.Pilot;

public interface IPilotDao {
	
	public void savePilot(Pilot pilot);

}
