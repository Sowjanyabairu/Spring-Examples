package org.cap.config;

import java.beans.BeanProperty;

import org.cap.model.Address;
import org.cap.model.Customer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;


@Configuration
public class JavaConfig {
	
	@Bean("emp")
	
	@Scope("prototype")
	public Customer getCustomer1() {
		
		Customer customer=new Customer(1004,"tom","chinni",2500,getAddress1());
		/*Customer customer=new Customer();
		customer.setCustId(1001);
		customer.setFirstName("Bairu");
		customer.setLastName("Sowjanya");
		customer.setRegfee(4000);
		customer.setAddress(getAddress());*/
	
		return customer;
		
	}
	
	
	@Bean("emp2")
public Customer getCustomer2() {
		
		Customer customer=new Customer();
		customer.setCustId(1001);
		customer.setFirstName("Bairu");
		customer.setLastName("Sowjanya");
		customer.setRegfee(4000);
		customer.setAddress(getAddress());
	
		return customer;
		
	}
	public Address getAddress() {
		Address address=new Address();
		address.setStreetName("Banjara Hills");
		address.setCity("Hyderabad");
		return address;
		
	}
	public Address getAddress1() {
		Address address=new Address();
		address.setStreetName("Jublie Hills");
		address.setCity("Hyderabad");
		return address;
		
	}

}
