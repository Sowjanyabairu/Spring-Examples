package org.cap.config;

import org.cap.model.Customer;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;


public class TestClass {

	public static void main(String[] args) {
		
			
		
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
		Customer customer1=(Customer)context.getBean("emp");
		System.out.println(customer1);
		customer1.setFirstName("tom");
		System.out.println(customer1);
		
Customer customer2=(Customer)context.getBean("emp2");
		
		System.out.println(customer2);
		context.close();
			
		}

}
