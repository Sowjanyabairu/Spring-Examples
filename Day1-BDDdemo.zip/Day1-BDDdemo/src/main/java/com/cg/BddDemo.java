package com.cg;

public class BddDemo {

	public static void main(String[] args) {
		System.out.println("Hello");

	}

} 