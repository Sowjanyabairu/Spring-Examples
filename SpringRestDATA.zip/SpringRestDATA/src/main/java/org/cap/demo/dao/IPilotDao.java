package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Pilot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public interface IPilotDao extends JpaRepository<Pilot,Integer> {
	
	public List<Pilot> findByIsCertified(boolean Certified);
	
	//@Query("from Pilot p where p.salary between ? and ?")
	//public List<Pilot> getAllPilots(double minsalary,double maxsalary);
	
	@Query("from Pilot p where p.salary between :minsal and :maxsal")
	public List<Pilot> getAllPilots(
			@Param("minsal") double minsalary,@Param("maxsal")double maxsalary);

	@Query("select p.firstName from Pilot p")
	public List<String> getAllNames();
	
	@Query("select new Pilot(p.firstName,p.lastName,p.salary) from Pilot p")
	public List<Pilot> getAllPilotsInfo();
	
	@Query("select p.firstName from Pilot p where p.firstName like '%a%' ")
	public List<String> getFirstNames();
	
	
}
