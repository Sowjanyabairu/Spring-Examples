package org.cap.exception;

public class InsufficientbalanceException extends Exception {

	public InsufficientbalanceException(String msg) {
		super(msg);
	}
	
}
