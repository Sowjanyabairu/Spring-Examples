package bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingPageBean {
	private String pageHeading;

	private String firstName;
	private String lastName;
	private String email;
	private String phone;
	private String address;
	private String city;
	private String state;
	private String numberOfGuestsstaying;

	private String cardHolderName;
	private String debitCardNumber;
	private String cvv;
	private String expireMonth;
	private String expireYear;
	private String confirmBtn;
	private WebDriver driver;
	public HotelBookingPageBean() {
		super();
	}
	public HotelBookingPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this); 

	}

	public HotelBookingPageBean(String pageHeading, String firstName, String lastName, String email, String phone,
			String address, String city, String state, String numberOfGuestsstaying, String cardHolderName,
			String debitCardNumber, String cvv, String expireMonth, String expireYear, String confirmBtn) {
		super();
		this.pageHeading = pageHeading;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.city = city;
		this.state = state;
		this.numberOfGuestsstaying = numberOfGuestsstaying;
		this.cardHolderName = cardHolderName;
		this.debitCardNumber = debitCardNumber;
		this.cvv = cvv;
		this.expireMonth = expireMonth;
		this.expireYear = expireYear;
		this.confirmBtn = confirmBtn;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		driver.findElement(By.name("txtFN")).sendKeys(firstName);
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		driver.findElement(By.name("txtLN")).sendKeys(lastName);
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		driver.findElement(By.name("Email")).sendKeys(email);
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		driver.findElement(By.name("Phone")).sendKeys(phone);
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys(address);
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		WebElement mySelectElement = driver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText(city);
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		WebElement mySelectstate = driver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText(state);
		this.state = state;
	}
	public String getNumberOfGuestsstaying() {
		return numberOfGuestsstaying;
	}
	public void setNumberOfGuestsstaying(String numberOfGuestsstaying) {
		WebElement persons = driver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText(numberOfGuestsstaying);
		this.numberOfGuestsstaying = numberOfGuestsstaying;
	}
	public String getCardHolderName() {

		return cardHolderName;
	}
	public void setCardHolderName(String cardHolderName) {
		driver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys(cardHolderName);
		this.cardHolderName = cardHolderName;
	}
	public String getDebitCardNumber() {
		return debitCardNumber;
	}
	public void setDebitCardNumber(String debitCardNumber) {
		driver.findElement(By.name("debit")).sendKeys(debitCardNumber);
		this.debitCardNumber = debitCardNumber;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		driver.findElement(By.name("cvv")).sendKeys(cvv);
		this.cvv = cvv;
	}
	public String getExpireMonth() {
		return expireMonth;
	}
	public void setExpireMonth(String expireMonth) {
		driver.findElement(By.name("month")).sendKeys(expireMonth);
		this.expireMonth = expireMonth;
	}
	public String getExpireYear() {
		return expireYear;
	}
	public void setExpireYear(String expireYear) {
		driver.findElement(By.name("year")).sendKeys(expireYear);
		this.expireYear = expireYear;
	}
	public String getPageHeading() {
		return driver.findElement(By.tagName("h2")).getText();
	}
	public void setPageHeading(String pageHeading) {
		this.pageHeading = pageHeading;
	}
	public String getConfirmBtn() {
		return confirmBtn;
	}
	public void setConfirmBtn(String confirmBtn) {
		this.confirmBtn = confirmBtn;
	}




	public void onSubmit_navigate_to_successPage() {
		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();


	} 
}
