package hotelBookingPage1;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.HotelBookingPageBean;
import bean.SuccessBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;
	private HotelBookingPageBean hotelBookingPageBean;
	private SuccessBean successBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\bairu\\chromedriver.exe");
		driver=new ChromeDriver();
		hotelBookingPageBean=new HotelBookingPageBean(driver);
		successBean = new SuccessBean(driver);
	}

	@Given("^open Hotel Booking page$")
	public void open_Hotel_Booking_page() throws Throwable {
		driver.get("http://localhost:8085/HotelManagementSystem/pages/hotelbooking.html");
		assertEquals("Hotel Booking Form",hotelBookingPageBean.getPageHeading());
	}

	@Given("^Personel and payment details$")
	public void personel_and_payment_details() throws Throwable {
	    hotelBookingPageBean.setFirstName("Sowjanya");
	    hotelBookingPageBean.setLastName("Bairu");
	    hotelBookingPageBean.setEmail("Sowji@gmail.com");
	    hotelBookingPageBean.setPhone("9874563210");
	    hotelBookingPageBean.setAddress("Tanuku");
	    hotelBookingPageBean.setCity("Hyderabad");
	    hotelBookingPageBean.setState("Telangana");
	    hotelBookingPageBean.setNumberOfGuestsstaying("2");
	    hotelBookingPageBean.setCardHolderName("Sowjanya");
	    hotelBookingPageBean.setDebitCardNumber("2874563210236547");
	    hotelBookingPageBean.setCvv("142");
	    hotelBookingPageBean.setExpireMonth("11");
	    hotelBookingPageBean.setExpireYear("2020");
	    Thread.sleep(1000);
	}

	@When("^Personel And payment details are not empty$")
	public void personel_And_payment_details_are_not_empty() throws Throwable {
	   hotelBookingPageBean.onSubmit_navigate_to_successPage();
	   Thread.sleep(1000);
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		driver.navigate().to("http://localhost:8085/HotelManagementSystem/pages/success.html");
		assertEquals("Booking Completed!",successBean.getMessage());
	}

	@Given("^Personel and payment details are null$")
	public void personel_and_payment_details_are_null() throws Throwable {
		driver.findElement(By.name("txtFN")).sendKeys("");
	}

	@When("^Personel And payment details are empty$")
	public void personel_And_payment_details_are_empty() throws Throwable {
		hotelBookingPageBean.onSubmit_navigate_to_successPage();
		   Thread.sleep(1000);
	}

	@Then("^show alert messages$")
	public void show_alert_messages() throws Throwable {
		String msg = driver.switchTo().alert().getText();
		assertEquals("Please fill the First Name",msg);
	}
	@After
	public void tearDown() {
		driver.quit();
	}


}
