package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.Model.ProductBean;
import com.capg.dao.IProductDao;

@Service("productService")
public class ProductServiceImpl implements IProductService{

	@Autowired
	private IProductDao productDao;
	
	
	@Override
	public List<ProductBean> saveProduct(ProductBean product) {
	
		productDao.save(product);
		
		return productDao.findAll();
	}

	@Override
	public List<ProductBean> getAllProducts() {

		
		return productDao.findAll();
	}

	@Override
	public List<ProductBean> deleteProduct(Integer productId) {
		
		productDao.deleteById(productId);
		return productDao.findAll();
	}

	@Override
	public List<ProductBean> updateProduct(ProductBean product) {

		productDao.save(product);
		return productDao.findAll();
	}

}
