package org.cap.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		
			
			AbstractApplicationContext context = new ClassPathXmlApplicationContext("myBeans.xml");
			Customer employees = (Customer)context.getBean("cust");
			employees.setLastName("Sowjanya");
			Customer employees1 = (Customer)context.getBean("cust");
			System.out.println(employees1);
			System.out.println(employees);
			
		AbstractApplicationContext context1 = new ClassPathXmlApplicationContext("myBeansCon.xml");
			Customer  employee = (Customer )context1.getBean("cust");
			employee.setLastName("Sowjanya");
			Customer  employee1 = (Customer )context1.getBean("cust");
			System.out.println(employee);
			System.out.println(employee1);
			context.close();
			context1.close();
			
			
		}

}
