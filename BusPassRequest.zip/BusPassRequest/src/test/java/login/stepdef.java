package login;

import org.cap.dao.ILoginDAO;
import org.cap.model.LoginBean;
import org.cap.service.ILoginService;
import org.cap.service.LoginServiceImpl;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
		private String username;
			private String password;
			private ILoginService loginService;
			private LoginBean login=new LoginBean();
			@Mock
			private ILoginDAO loginDao;

			@Before
			public void setUp() {
				MockitoAnnotations.initMocks(this);
				loginService=new LoginServiceImpl(loginDao);

			}
			@Given("^username$")
			public void username() throws Throwable {
				this.username="sow";

			}

			@Given("^password$")
			public void password() throws Throwable {
				this.password="sow123";
			}

			@When("^valid user$")
			public void valid_user() throws Throwable {

				this.login.setUsername(this.username);
				this.login.setPassword(this.password);
				//dummy declarion
				Mockito.when(loginDao.checkUser(this.login)).thenReturn(true);

				//Actual Logic
				boolean flag= loginService.checkUser(this.login);

				//Mockito Verification
				Mockito.verify(loginDao).checkUser(this.login);
				//assertTrue(flag);
			}

			@Then("^redirect to menu page$")
			public void redirect_to_menu_page() throws Throwable {
				// Write code here that turns the phrase above into concrete actions
				throw new PendingException();
			}

		}  
		 


