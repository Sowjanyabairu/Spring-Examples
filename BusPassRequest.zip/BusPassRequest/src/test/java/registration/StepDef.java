package registration;

import static org.junit.Assert.assertEquals;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	
		
			
			private WebDriver driver;

			@Before
			public void setUp() {
				System.setProperty("webdriver.chrome.driver",
						"C:\\bairu\\chromedriver.exe");
				driver=new ChromeDriver();
			}
			
			@Given("^open buspass registration page$")
			public void open_buspass_registration_page() throws Throwable {
				driver.get("http://localhost:8085/BusPassRequest/pages/requestform.html?");
				/*String title=driver.getTitle();
				assertEquals("Insert title here",title);*/
				Thread.sleep(3000);
			    
			}

			@Given("^details of the user$")
			public void details_of_the_user() throws Throwable {
				driver.findElement(By.name("empid")).sendKeys("162315");
				driver.findElement(By.name("fname")).sendKeys("Sruthi");
				driver.findElement(By.name("lname")).sendKeys("yelam");
				driver.findElement(By.name("emailid")).sendKeys("sruthi@gmail.com");
				WebElement radio=driver.findElement(By.id("gender-female"));
				radio.click();
				Select designation=new Select(driver.findElement(By.name("designation")));
				designation.selectByVisibleText("Software Enginner");
				driver.findElement(By.name("address")).sendKeys("Hyderabad");
				driver.findElement(By.name("doj")).sendKeys("10102018");
				Select location=new Select(driver.findElement(By.name("location")));
				location.selectByVisibleText("Chennai SIPCOT");
				Select pickuploc=new Select(driver.findElement(By.name("pickuplocation")));
				pickuploc.selectByVisibleText("Parnur");
				driver.findElement(By.name("pickuptime")).sendKeys("0800PM");
				Thread.sleep(5000);
			    
			}

			@When("^submit after details entered$")
			public void submit_after_details_entered() throws Throwable {
				WebElement login=driver.findElement(By.name("submit"));
				login.submit();
				Thread.sleep(3000);
			    
			}

			@Then("^redirect to successfulpage$")
			public void redirect_to_successfulpage() throws Throwable {
				driver.navigate().to("http://localhost:8085/BusPassRequest/pages/request.html");
			    
			}
			
			@After
			public void tearDown() {
				driver.quit();
			} 
		 


}
